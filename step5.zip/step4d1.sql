-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2023 at 06:50 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `step4d1`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `Id` int(11) NOT NULL,
  `text` varchar(200) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`Id`, `text`, `date`) VALUES
(0, 'You too', '2020-01-01'),
(1, 'Happy to all', '2020-01-01'),
(2, 'F*** off', '2020-04-23'),
(3, 'ME', '2020-03-30'),
(4, 'I like eating sausages', '2020-06-05');

-- --------------------------------------------------------

--
-- Table structure for table `comments_likes`
--

CREATE TABLE `comments_likes` (
  `user` int(11) DEFAULT NULL,
  `comment` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments_likes`
--

INSERT INTO `comments_likes` (`user`, `comment`) VALUES
(0, 0),
(1, 4),
(1, 2),
(2, 0),
(5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `manager` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`, `city`, `manager`) VALUES
(0, 'Neuralink', 'San Francisco', 1),
(1, 'Google', 'Mountain View', 6),
(2, 'Sokolow', 'Sokolow Podlaski', 11),
(3, 'Apple', 'San Francisco', NULL),
(4, 'Sabanci University', 'Kocaeli', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `connections`
--

CREATE TABLE `connections` (
  `user1` int(11) NOT NULL,
  `user2` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connections`
--

INSERT INTO `connections` (`user1`, `user2`) VALUES
(0, 5),
(1, 6),
(2, 7),
(3, 9),
(5, 11);

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `Id` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `company` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`Id`, `user`, `start`, `end`, `position`, `company`) VALUES
(0, 9, '2013-04-30', NULL, 'CEO', 0),
(1, 9, '2011-12-11', '2013-04-30', 'Administrator', 0),
(2, 6, '2013-04-30', '2015-10-27', 'Manager', 0),
(3, 10, '2014-11-04', NULL, 'CEO', 1),
(4, 11, '2017-06-13', NULL, 'CTO', 1);

-- --------------------------------------------------------

--
-- Table structure for table `management`
--

CREATE TABLE `management` (
  `company` int(11) NOT NULL,
  `user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `management`
--

INSERT INTO `management` (`company`, `user`) VALUES
(0, 0),
(0, 3),
(0, 5),
(1, 7),
(1, 8),
(1, 11),
(2, 6),
(2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `author_comp` int(11) DEFAULT NULL,
  `author_usr` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `text` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `author_comp`, `author_usr`, `date`, `text`) VALUES
(0, NULL, 0, '2020-01-01', 'Happy new year!'),
(1, NULL, 0, '2020-03-11', 'Lol'),
(2, NULL, 3, '2021-04-22', 'Hi I guess?'),
(3, NULL, 3, '2020-04-16', 'Remember, the more celebs tell you to stay at home the safer there is'),
(5, 0, NULL, '2020-03-17', 'Who doesnt like rats'),
(6, 2, NULL, '2020-06-01', 'Pyszne paroweczki'),
(7, NULL, 11, '2020-06-03', 'I like eating carbon'),
(8, 3, NULL, '2030-05-05', 'iPhone 28 is now out with 128 terabytes of storage!!'),
(12, 0, 11, '2020-10-10', 'berke barisca');

-- --------------------------------------------------------

--
-- Table structure for table `support`
--

CREATE TABLE `support` (
  `id` int(11) NOT NULL,
  `author` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `text` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `support`
--

INSERT INTO `support` (`id`, `author`, `date`, `text`) VALUES
(0, 1, '2023-01-02', 'This is a test'),
(3, 0, '2023-01-02', 'kjdbsahvcda'),
(4, 0, '2023-01-02', 'selamÄ±n sa');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `password`) VALUES
(0, 'Magnus', 'Carlsen', '21733821'),
(1, 'Hikaru', 'Nakamura', '114343'),
(2, 'Levon', 'Aronian', '654453432'),
(3, 'Ian', 'Nepomniachtchi', '43243242'),
(5, 'Peter', 'Svidler', '2342424'),
(6, 'Wesley', 'So', '76575'),
(7, 'Alireza', 'Firouzja', '34534'),
(8, 'Fabiano', 'Caruana', '2342'),
(9, 'We', 'Yi', '98209432'),
(10, 'Hou', 'Yifan', '92809432'),
(11, 'Arkady', 'Dvorkovich', '98209432'),
(13, 'asdsa', 'dsadsa', 'dsad'),
(15, 'Baran', 'Pekkolay', 'baran123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `comments_likes`
--
ALTER TABLE `comments_likes`
  ADD KEY `comm_like_usr_fk` (`user`),
  ADD KEY `comm_like_comp_fk` (`comment`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_manager_fk` (`manager`);

--
-- Indexes for table `connections`
--
ALTER TABLE `connections`
  ADD KEY `connections_usr1fk` (`user1`),
  ADD KEY `connections_usr2fk` (`user2`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `exp_user_fk` (`user`);

--
-- Indexes for table `management`
--
ALTER TABLE `management`
  ADD PRIMARY KEY (`company`,`user`),
  ADD KEY `management_user_fk` (`user`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_comp_fk` (`author_comp`),
  ADD KEY `post_usr_fk` (`author_usr`);

--
-- Indexes for table `support`
--
ALTER TABLE `support`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `support`
--
ALTER TABLE `support`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments_likes`
--
ALTER TABLE `comments_likes`
  ADD CONSTRAINT `comm_like_comp_fk` FOREIGN KEY (`comment`) REFERENCES `comments` (`Id`),
  ADD CONSTRAINT `comm_like_usr_fk` FOREIGN KEY (`user`) REFERENCES `users` (`id`);

--
-- Constraints for table `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `company_manager_fk` FOREIGN KEY (`manager`) REFERENCES `users` (`id`);

--
-- Constraints for table `connections`
--
ALTER TABLE `connections`
  ADD CONSTRAINT `connections_usr1fk` FOREIGN KEY (`user1`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `connections_usr2fk` FOREIGN KEY (`user2`) REFERENCES `users` (`id`);

--
-- Constraints for table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `exp_user_fk` FOREIGN KEY (`user`) REFERENCES `users` (`id`);

--
-- Constraints for table `management`
--
ALTER TABLE `management`
  ADD CONSTRAINT `management_company_fk` FOREIGN KEY (`company`) REFERENCES `company` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `management_user_fk` FOREIGN KEY (`user`) REFERENCES `users` (`id`);

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_comp_fk` FOREIGN KEY (`author_comp`) REFERENCES `company` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_usr_fk` FOREIGN KEY (`author_usr`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
